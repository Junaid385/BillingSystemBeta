
import React from 'react';

import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Tab from 'react-bootstrap/Tab';
import Tabs from 'react-bootstrap/Tabs';

import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Home from "./Components/MyItems";
import NewBill from "./Components/NewBill";
import MyBill from "./Components/MyBill";
import MySales from "./Components/Sales";
import './App.css';
function App() {
  return (
    <Router>
      <main>
        <Row className="min-vh-100 g-0 border">
          <Col xs={10}>
            <Tabs
              defaultActiveKey="Items"
              id="uncontrolled-tab-example"
              className="mb-3"
            >
              <Tab eventKey="Items" title="Items">
                <Home></Home>
              </Tab>
              <Tab eventKey="New Bill" title="New Bill">
                <NewBill></NewBill>
              </Tab>
              <Tab eventKey="MyBill" title="MyBill">
                <MyBill></MyBill>
              </Tab>
              <Tab eventKey="MySale" title="MySale">
                <MySales></MySales>
              </Tab>
            </Tabs>
          </Col>
          <Col>
            <Routes>
              {/* <Route path="/" element={<Home />} /> */}
              {/* <Route path="/available-devices" element={<Devices />} /> */}

            </Routes>
          </Col>
        </Row>
      </main>
    </Router>

  );
}

export default App;
