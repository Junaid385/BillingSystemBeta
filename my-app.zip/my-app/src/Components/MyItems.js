import React, { useEffect, useState } from 'react';
import Badge from 'react-bootstrap/Badge';
import ListGroup from 'react-bootstrap/ListGroup';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button'
import Modal from 'react-bootstrap/Modal'
import Form from 'react-bootstrap/Form'
import Api from './Api'

function MyItems() {

    const [show, setShow] = useState(false);
    const [Items, setItems] = useState({});

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);



    const getItems = async () => {


        let rs = await Api.getItems()
        setItems(rs[0].Items)

    }
    useEffect(() => {
        getItems()

    }, [])


    return (
        <>
            <Container id='mycard'>
                <Card >


                    <h1>Items</h1>
                    <ListGroup as="ul" none>

                        {/* 
                        {
                            Object.entries(Items).forEach(([key, value]) => {
                                return (
                                    <>
                                        <ListGroup.Item
                                            as="li"
                                            className="d-flex justify-content-between align-items-start">
                                            <div className="ms-2 me-auto">
                                                <div className="fw-bold">{key}</div>
                                              sold 12
                                            </div>

                                            {value}
                                        </ListGroup.Item>
                                    </>
                                )
                            })
                        } */}


                        <ListGroup.Item
                            as="li"
                            className="d-flex justify-content-between align-items-start"
                        >
                            <div className="ms-2 me-auto">
                                <div className="fw-bold">Eraser</div>
          sold 12
        </div>

                        14

                </ListGroup.Item>
                        <ListGroup.Item
                            as="li"
                            className="d-flex justify-content-between align-items-start"
                        >
                            <div className="ms-2 me-auto">
                                <div className="fw-bold">Pen</div>
          sold 12
        </div>

                        14

                </ListGroup.Item>
                        <ListGroup.Item
                            as="li"
                            className="d-flex justify-content-between align-items-start"
                        >
                            <div className="ms-2 me-auto">
                                <div className="fw-bold">Book</div>
          sold 12
        </div>

                        14

                </ListGroup.Item>
                    </ListGroup>

                </Card>
            </Container>
            <Button onClick={handleShow} className='rounded-circle myaddbtn' variant="info">+</Button>{' '}

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Modal heading</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Email address</Form.Label>
                            <Form.Control
                                type="email"
                                placeholder="name@example.com"
                                autoFocus
                            />
                        </Form.Group>
                        <Form.Group
                            className="mb-3"
                            controlId="exampleForm.ControlTextarea1"
                        >
                            <Form.Label>Example textarea</Form.Label>
                            <Form.Control as="textarea" rows={3} />
                        </Form.Group>
                    </Form>
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
          </Button>
                    <Button variant="primary" onClick={handleClose}>
                        Save Changes
          </Button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default MyItems;
