

const Api = {}
const Reload = () => {
    window.location.reload()
}
const postApi = (url, data) => {
    return new Promise((resolve, reject) => {
        fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            withCredentials: true,
            body: JSON.stringify(data)
        })
            .then(response => response.json())
            .then(data => resolve(data))
            .catch((error) => reject(error))
    })
}
const getApi = (url) => {
    return new Promise((resolve, reject) => {
        fetch(url, {
            method: 'GET',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            withCredentials: true
        })
            .then(response => response.json())
            .then(data => resolve(data))
            .catch(error => reject(error))
    })
}


Api.getItems = () => {
    return new Promise((resolve, reject) => {
        var requestOptions = {
            method: 'GET',
            redirect: 'follow',
        };

        fetch("http://localhost:3000/getItems", requestOptions)
            .then(response => response.json())
            .then(result => {
                console.log(result)
                resolve(result)
            })
            .catch(error => console.log('error', error));

    })
}
export default Api


