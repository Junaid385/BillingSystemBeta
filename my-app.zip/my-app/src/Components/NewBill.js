import React from 'react';
import Badge from 'react-bootstrap/Badge';
import ListGroup from 'react-bootstrap/ListGroup';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button'

function NewBill() {
    return (
        <>
            <Container id='mycard'>
                <Card >
                    <h1>New Bill</h1>
                    <Button className='rounded-circle myaddbtn' >cart</Button>{' '}
                    <Button className='rounded-circle myaddbtn1' variant="info">+</Button>{' '}
                    <ListGroup as="ul" none>
                        <ListGroup.Item
                            as="li"
                            className="d-flex justify-content-between align-items-start"
                        >
                            <div className="ms-2 me-auto">
                                <div className="fw-bold">Eraser</div>
          sold 12
        </div>

                        14

                </ListGroup.Item>

                    </ListGroup>

                </Card>
            </Container>
            <div id='footer'>
                <h1>Hello</h1>
            </div>

        </>
    );
}

export default NewBill;
