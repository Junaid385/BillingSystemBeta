import React from 'react';
import Badge from 'react-bootstrap/Badge';
import ListGroup from 'react-bootstrap/ListGroup';
import Card from 'react-bootstrap/Card';
import Container from 'react-bootstrap/Container';
import Button from 'react-bootstrap/Button'

function MySales() {
    return (
        <>
            <Container id='mycard'>
                <Card >


                    <h1>Sales</h1>
                    <div id='box'>
                        <div className='sales'>
                            <h1>Rs 2000</h1>
                            <h3>today</h3>
                        </div>

                        <div className='sales'>
                            <h1>Rs 2000</h1>
                            <h3>today</h3>
                        </div>

                        <div className='sales'>
                            <h1>Rs 2000</h1>
                            <h3>today</h3>
                        </div>
                    </div>


                </Card>
            </Container>

        </>
    );
}

export default MySales;
