
const { config } = require('dotenv')
const express = require('express')
const { MongoClient } = require('mongodb');
const app = express()
const port = 3000


app.get('/getItems', async (req, res) => {
    res.set('Access-Control-Allow-Origin', '*');
    const url = 'mongodb+srv://billing:123@cluster0.fm38r.mongodb.net/?retryWrites=true&w=majority';
    const client = new MongoClient(url);

    // Database Name
    const dbName = 'billing';

    async function main() {
        // Use connect method to connect to the server
        await client.connect();
        console.log('Connected successfully to server');
        const db = client.db(dbName);
        const collection = db.collection('Items');
        let result = await collection.find({}).toArray()


        return result;
    }

    let rs = await main().catch(error => {
        console.log(error)
    }).finally(() => client.close());

    res.send(rs)


})


app.post('/saveItems', (req, res) => {
    res.send('POST request to the homepage')
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})

config();
console.log(process.env.DB_URI);